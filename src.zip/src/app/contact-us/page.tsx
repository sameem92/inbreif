import ContactUsComponent from "@/components/contactUs/contactUs"

export const metadata = {
  title: "تواصل معنا | شركة إن بريف للبرمجة والتسويق",
}

export default function ContactUsPage() {
  return <ContactUsComponent />
}
