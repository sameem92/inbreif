import Home from "@/components/home/Home"

export default function Main() {
  return <Home />
}
