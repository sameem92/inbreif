import Home from "@/components/about/Home"

export const metadata = {
  title: "من نحن | شركة إن بريف للبرمجة والتسويق",
}

export default function Main() {
  return <Home />
}
