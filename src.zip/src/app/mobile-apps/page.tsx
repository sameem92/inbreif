import Home from "@/components/mobile/Home"

export const metadata = {
  title: "تطوير وتصميم تطبيقات جوال | شركة إن بريف للبرمجة والتسويق",
  description:
    "متخصصون في تصميم وبرمجة تطبيقات الجوال بخبرة عالية وأحدث التقنيات تعمل على نظامي التشغيل iOS  وأندرويدAndroid  احصل على تطبيق جوال الآن. ",
}

export default function Main() {
  return <Home />
}
