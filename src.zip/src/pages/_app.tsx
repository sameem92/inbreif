// Create a client-side cache, if not available

export default function MyApp({ Component, pageProps }) {
  return <Component {...pageProps} />
}
