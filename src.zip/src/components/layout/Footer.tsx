import React from "react"
import { Box, Typography, Grid } from "@mui/material"
import Container from "@mui/material/Container"
import Image from "next/image"
import Fade from "@mui/material/Fade"
import useScrollTrigger from "@mui/material/useScrollTrigger"
import { useRouter } from "next/navigation"
import footer from "../../../public/image/fo.png"
import timer from "../../../public/image/time.png"
import email from "../../../public/image/email.png"
import location from "../../../public/image/location.png"
import phone from "../../../public/image/phone.png"
import up from "../../../public/image/up.png"

function ScrollTop() {
  const trigger = useScrollTrigger({
    disableHysteresis: true,
    threshold: 10, // Try setting a low threshold for testing
  })

  // Log to check when the trigger fires
  const handleClick = (event: React.MouseEvent<HTMLDivElement>) => {
    const anchor = ((event.target as HTMLDivElement).ownerDocument || document).querySelector("#goToHome")
    if (anchor) {
      anchor.scrollIntoView({
        block: "center",
        behavior: "smooth",
      })
    }
  }
  return (
    <Fade in={trigger}>
      <Box
        onClick={handleClick}
        role="presentation"
        sx={{
          position: "fixed",
          bottom: 16,
          right: 16,
          cursor: "pointer",
          zIndex: 1000,
        }}
      >
        <Image
          onClick={handleClick}
          width={50}
          height={50}
          src={up}
          alt="up"
          style={{ cursor: "pointer", width: "5rem", height: "5rem" }}
        />
      </Box>
    </Fade>
  )
}

export default function ResponsiveFooter() {
  const router = useRouter()

  const handleNavigation = (path: string) => {
    router.push(path)
  }

  return (
    <Box
      component="footer"
      className="footer"
      sx={{
        color: "white",
        padding: { xs: "5rem 0", lg: "10rem 10rem 3rem 10rem" },
      }}
    >
      <Container
        maxWidth="lg"
        sx={{
          display: "flex",
          flexDirection: "column",

          justifyContent: "center",
          gap: "4rem",
        }}
      >
        <Box
          sx={{
            display: "flex",
            gap: "1.6rem",
            flexDirection: "column",
            justifyContent: "space-between",
            width: "100%",
          }}
        >
          <Grid container direction={"row"} spacing={{ xs: 3, md: 3 }} style={{ alignItems: "flex-start" }}>
            {/* Column 1 */}
            <Grid item xs={12} md={4}>
              <Box
                sx={{
                  display: "flex",
                  alignItems: "flex-start",
                  gap: { xs: "2rem", md: "3.2rem" },
                  flexDirection: "column",
                }}
              >
                <Image src={footer} alt="footer" width={172} height={60} className="footer-logo" />
                <Typography
                  variant="body2"
                  sx={{
                    // fontFamily: "var(--font-ibm-plex-sans-arabic)",
                    fontSize: "2.4rem",
                    fontWeight: 600,
                    lineHeight: "3.6rem",
                  }}
                >
                  المنصة الأقوى في البرمجيات والتسويق في العالم العربي.
                </Typography>

                <Typography
                  variant="body2"
                  sx={{
                    fontFamily: "Kumbh Sans, sans-serif",
                    fontSize: "1.6rem",
                    fontWeight: 500,
                    lineHeight: "2rem",
                    textAlign: "right",
                  }}
                >
                  ⁠مرخصة برقم : س ت 1559152
                </Typography>
                <Box sx={{ display: "flex", alignItems: "center", gap: "0.7rem" }}>
                  <Image src={timer} alt="timer" width={36} height={36} />

                  <Typography
                    variant="body2"
                    sx={{
                      fontFamily: "Kumbh Sans, sans-serif",
                      fontSize: "1.6rem",
                      fontWeight: 400,
                      lineHeight: "2rem",
                      textAlign: "left",
                    }}
                  >
                    <strong>أوقات الدوام</strong>: من الساعة 8 صباحاً إلى 8 مساءً يومياً عدا الجمعة
                  </Typography>
                </Box>
                <div className="social-menu-footer">
                  <ul>
                    <li>
                      <a
                        href="https://www.facebook.com/inbriefclick/"
                        target="_blank"
                        rel="noopener noreferrer"
                        title="Facebook"
                      >
                        <svg width="10" height="18" viewBox="0 0 10 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path
                            d="M6.66532 10.2493H8.74872L9.58202 6.91602H6.66532V5.24936C6.66532 4.39102 6.66532 3.58269 8.33202 3.58269H9.58202V0.782686C9.31032 0.746856 8.28452 0.666016 7.20122 0.666016C4.93869 0.666016 3.33203 2.04686 3.33203 4.58269V6.91602H0.832031V10.2493H3.33203V17.3327H6.66532V10.2493Z"
                            fill="#124651"
                          />
                        </svg>
                      </a>
                    </li>
                    <li>
                      <a
                        href="https://www.x.com/inbriefclick"
                        target="_blank"
                        rel="noopener noreferrer"
                        title="Twitter"
                      >
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path
                            d="M18.4663 4.71376C17.8301 4.99517 17.1554 5.17999 16.4646 5.26209C17.1927 4.82662 17.7377 4.14127 17.9979 3.33376C17.3146 3.74043 16.5654 4.02543 15.7846 4.17959C15.2601 3.61841 14.5649 3.24623 13.8071 3.12091C13.0492 2.9956 12.2712 3.12417 11.594 3.48664C10.9167 3.84911 10.3782 4.42516 10.0622 5.12525C9.74617 5.82534 9.67026 6.61024 9.84631 7.35793C8.46056 7.28847 7.10492 6.92836 5.86738 6.30098C4.62984 5.6736 3.53808 4.79297 2.66297 3.71626C2.35321 4.2483 2.19043 4.85312 2.19131 5.46876C2.19131 6.67709 2.80631 7.74459 3.74131 8.36959C3.18798 8.35217 2.64683 8.20274 2.16297 7.93376V7.97709C2.16314 8.78184 2.44161 9.56177 2.95118 10.1846C3.46074 10.8075 4.17004 11.235 4.95881 11.3946C4.44515 11.5338 3.90656 11.5543 3.38381 11.4546C3.60619 12.1473 4.03964 12.7531 4.62347 13.1872C5.20729 13.6213 5.91225 13.8619 6.63964 13.8754C5.91671 14.4432 5.08895 14.8629 4.20371 15.1106C3.31846 15.3582 2.39308 15.429 1.48047 15.3188C3.07355 16.3433 4.92805 16.8872 6.82214 16.8854C13.2329 16.8854 16.7388 11.5746 16.7388 6.96876C16.7388 6.81876 16.7346 6.66709 16.7279 6.51876C17.4103 6.02557 17.9993 5.41461 18.4671 4.71459L18.4663 4.71376Z"
                            fill="#124651"
                          />
                        </svg>
                      </a>
                    </li>
                    <li>
                      <a
                        href="https://www.instagram.com/inbriefclick"
                        target="_blank"
                        rel="noopener noreferrer"
                        title="Instagram"
                      >
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <g clip-path="url(#clip0_280_28919)">
                            <path
                              d="M10.0013 1.66602C12.2655 1.66602 12.548 1.67436 13.4363 1.71602C14.3238 1.75769 14.928 1.89686 15.4597 2.10352C16.0097 2.31519 16.473 2.60186 16.9363 3.06436C17.3601 3.48094 17.688 3.98485 17.8972 4.54102C18.103 5.07186 18.243 5.67686 18.2847 6.56436C18.3238 7.45269 18.3347 7.73519 18.3347 9.99933C18.3347 12.2635 18.3263 12.546 18.2847 13.4343C18.243 14.3218 18.103 14.926 17.8972 15.4577C17.6886 16.0141 17.3606 16.5182 16.9363 16.9343C16.5196 17.3579 16.0158 17.6858 15.4597 17.8952C14.9288 18.101 14.3238 18.241 13.4363 18.2827C12.548 18.3218 12.2655 18.3327 10.0013 18.3327C7.73714 18.3327 7.45464 18.3243 6.56631 18.2827C5.67881 18.241 5.07464 18.101 4.54297 17.8952C3.98658 17.6864 3.48258 17.3584 3.06631 16.9343C2.64248 16.5178 2.31458 16.0139 2.10547 15.4577C1.89881 14.9268 1.75964 14.3218 1.71797 13.4343C1.67881 12.546 1.66797 12.2635 1.66797 9.99933C1.66797 7.73519 1.67631 7.45269 1.71797 6.56436C1.75964 5.67602 1.89881 5.07269 2.10547 4.54102C2.314 3.98451 2.64198 3.48046 3.06631 3.06436C3.4827 2.64038 3.98666 2.31246 4.54297 2.10352C5.07464 1.89686 5.67797 1.75769 6.56631 1.71602C7.45464 1.67686 7.73714 1.66602 10.0013 1.66602ZM10.0013 5.83269C8.89624 5.83269 7.83643 6.27168 7.05503 7.05308C6.27363 7.83448 5.83464 8.89429 5.83464 9.99933C5.83464 11.1044 6.27363 12.1642 7.05503 12.9456C7.83643 13.727 8.89624 14.166 10.0013 14.166C11.1064 14.166 12.1662 13.727 12.9476 12.9456C13.729 12.1642 14.168 11.1044 14.168 9.99933C14.168 8.89429 13.729 7.83448 12.9476 7.05308C12.1662 6.27168 11.1064 5.83269 10.0013 5.83269ZM15.418 5.62436C15.418 5.34809 15.3082 5.08314 15.1129 4.88779C14.9175 4.69244 14.6526 4.58269 14.3763 4.58269C14.1001 4.58269 13.8351 4.69244 13.6398 4.88779C13.4444 5.08314 13.3347 5.34809 13.3347 5.62436C13.3347 5.90062 13.4444 6.16557 13.6398 6.36093C13.8351 6.55628 14.1001 6.66602 14.3763 6.66602C14.6526 6.66602 14.9175 6.55628 15.1129 6.36093C15.3082 6.16557 15.418 5.90062 15.418 5.62436ZM10.0013 7.49936C10.6644 7.49936 11.3003 7.76275 11.7691 8.23159C12.2379 8.70043 12.5013 9.33631 12.5013 9.99933C12.5013 10.6624 12.2379 11.2983 11.7691 11.7671C11.3003 12.2359 10.6644 12.4993 10.0013 12.4993C9.33826 12.4993 8.70238 12.2359 8.23354 11.7671C7.7647 11.2983 7.50131 10.6624 7.50131 9.99933C7.50131 9.33631 7.7647 8.70043 8.23354 8.23159C8.70238 7.76275 9.33826 7.49936 10.0013 7.49936Z"
                              fill="#124651"
                            />
                          </g>
                          <defs>
                            <clipPath id="clip0_280_28919">
                              <rect width="20" height="20" fill="white" />
                            </clipPath>
                          </defs>
                        </svg>
                      </a>
                    </li>
                    <li>
                      <a
                        href="https://www.tiktok.com/@inbriefclick_?_t=8sTax1zYfOp&_r=1"
                        target="_blank"
                        rel="noopener noreferrer"
                        title="Tiktok"
                      >
                        <svg width="18" height="22" viewBox="0 0 18 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path
                            d="M9.45377 0.018342C10.5846 6.96955e-08 11.7071 0.00953778 12.8289 0C12.8662 1.4901 13.4354 2.83125 14.341 3.82465L14.3396 3.82318C15.3143 4.75569 16.5825 5.36023 17.9807 5.46295L18 5.46442V9.15921C16.6792 9.12399 15.4372 8.80044 14.3175 8.24431L14.3741 8.26926C13.8326 7.99266 13.3746 7.70873 12.9394 7.39178L12.9753 7.41673C12.967 10.0939 12.9836 12.7711 12.9581 15.4387C12.8869 16.7982 12.4614 18.0382 11.7789 19.0734L11.7927 19.0506C10.6516 20.7865 8.80306 21.9259 6.70104 21.9934H6.69137C6.6064 21.9978 6.50624 22 6.40539 22C5.21035 22 4.09337 21.6464 3.14149 21.0323L3.16912 21.0492C1.43666 19.942 0.241626 18.0477 0.0205793 15.8445L0.0178163 15.8144C0.000546956 15.3558 -0.00774237 14.8973 0.00952694 14.4483C0.348005 10.942 3.11386 8.22964 6.47585 8.22964C6.8537 8.22964 7.22395 8.26412 7.58385 8.32942L7.54516 8.32355C7.56243 9.68012 7.51062 11.0374 7.51062 12.394C7.21843 12.2817 6.88133 12.2164 6.52973 12.2164C5.23936 12.2164 4.14173 13.0924 3.73555 14.3155L3.72934 14.3375C3.63746 14.6508 3.58427 15.011 3.58427 15.3837C3.58427 15.5349 3.59325 15.6845 3.60983 15.8313L3.60845 15.8136C3.83779 17.3147 5.0494 18.4475 6.51039 18.4475C6.55252 18.4475 6.59397 18.4468 6.63542 18.4446H6.6292C7.6398 18.4123 8.51708 17.8349 9.01305 16.9817L9.01996 16.9685C9.2044 16.6955 9.33081 16.3654 9.37294 16.0066L9.37364 15.9963C9.45998 14.3551 9.42544 12.7234 9.43373 11.0822C9.44202 7.38738 9.42544 3.70139 9.451 0.0161409L9.45377 0.018342Z"
                            fill="#124651"
                          />
                        </svg>
                      </a>
                    </li>
                    <li>
                      <a
                        href="https://www.linkedin.com/company/inbriefclick"
                        target="_blank"
                        rel="noopener noreferrer"
                        title="Linkedin"
                      >
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path
                            fill-rule="evenodd"
                            clip-rule="evenodd"
                            d="M18 18H14.4V11.7009C14.4 9.97288 13.6377 9.00879 12.2706 9.00879C10.7829 9.00879 9.9 10.0134 9.9 11.7009V18H6.3V6.3H9.9V7.61572C9.9 7.61572 11.0295 5.63379 13.5747 5.63379C16.1208 5.63379 18 7.18749 18 10.4023V18ZM2.1978 4.42881C0.983701 4.42881 0 3.43706 0 2.21396C0 0.991765 0.983701 0 2.1978 0C3.411 0 4.3947 0.991765 4.3947 2.21396C4.3956 3.43706 3.411 4.42881 2.1978 4.42881ZM0 18H4.5V6.3H0V18Z"
                            fill="#124651"
                          />
                        </svg>
                      </a>
                    </li>
                    <li>
                      <a
                        href="https://snapchat.com/t/g12guzDD"
                        target="_blank"
                        rel="noopener noreferrer"
                        title="Snapchat"
                      >
                        <svg width="20" height="18" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path
                            d="M10.1711 0.00192776C10.1904 0.00192776 10.2138 0.00128515 10.2371 0.00128515C12.404 0.00128515 14.2682 1.24789 15.0999 3.03748L15.1132 3.07026C15.3353 3.8285 15.4627 4.69856 15.4627 5.59817C15.4627 6.07947 15.426 6.55241 15.3553 7.01507L15.362 6.96237L15.3593 7.01057C15.3493 7.15515 15.3413 7.28752 15.3346 7.41989C15.4227 7.46616 15.5274 7.49315 15.6388 7.49315C15.6494 7.49315 15.6601 7.49315 15.6708 7.4925H15.6695C15.9883 7.46359 16.2804 7.37748 16.5432 7.24511L16.5305 7.25089C16.6385 7.1982 16.7653 7.16736 16.9 7.16736C16.906 7.16736 16.912 7.16736 16.918 7.16736C16.9233 7.16736 16.9287 7.16736 16.9347 7.16736C17.0807 7.16736 17.2208 7.1937 17.3495 7.24254L17.3415 7.23997C17.6723 7.31515 17.9204 7.58182 17.9531 7.90954V7.91275C17.9656 8.27345 17.6285 8.58618 16.942 8.85092C16.868 8.87405 16.7679 8.91132 16.6552 8.94667C16.2804 9.05526 15.7061 9.23583 15.5441 9.59696C15.5201 9.67021 15.5067 9.75375 15.5067 9.84114C15.5067 10.0095 15.5581 10.1663 15.6461 10.2974L15.6441 10.2942L15.6568 10.3064C16.4018 11.9083 17.8484 13.0977 19.6092 13.5212L19.6498 13.5296C19.8493 13.561 20 13.7262 20 13.9254C20 13.9299 20 13.9344 20 13.9389C19.9993 14.0044 19.986 14.0655 19.9613 14.122L19.9627 14.1188C19.7626 14.5757 18.9015 14.9124 17.3408 15.1392C17.2828 15.2703 17.2355 15.4245 17.2061 15.5839L17.2041 15.5967C17.1734 15.769 17.1348 15.9187 17.0861 16.0639L17.0927 16.0408C17.0467 16.229 16.8733 16.3672 16.6672 16.3672C16.6546 16.3672 16.6412 16.3666 16.6285 16.3653H16.6299H16.6052C16.4411 16.3569 16.2877 16.3357 16.139 16.3023L16.157 16.3055C15.8389 16.2368 15.474 16.1969 15.0992 16.1969C15.0979 16.1969 15.0972 16.1969 15.0959 16.1969C15.0799 16.1969 15.0605 16.1963 15.0412 16.1963C14.7917 16.1963 14.5476 16.2181 14.3102 16.2599L14.3349 16.256C13.7813 16.3987 13.3004 16.6435 12.8929 16.9706L12.8989 16.9661C12.1599 17.5727 11.2075 17.9563 10.1631 18H10.1537C10.1037 18 10.0544 17.9878 10.0037 17.9878H9.87961C8.82916 17.9492 7.87875 17.5643 7.14109 16.9487L7.14643 16.9532C6.74892 16.6313 6.27205 16.3865 5.74983 16.249L5.72381 16.2432C5.49305 16.2078 5.2256 16.186 4.95281 16.1841H4.95015C4.57131 16.1892 4.20649 16.2329 3.855 16.31L3.89035 16.3036C3.75763 16.3351 3.60356 16.3563 3.44549 16.3627H3.44082C3.43015 16.3633 3.41815 16.364 3.40614 16.364C3.18938 16.364 3.00797 16.2213 2.95595 16.0286L2.95528 16.0253C2.90459 15.8711 2.88058 15.7131 2.84257 15.5698C2.81122 15.3969 2.7632 15.2433 2.6985 15.0981L2.70384 15.1122C1.10515 14.9342 0.24544 14.5969 0.0460199 14.1278C0.0200087 14.0751 0.00333478 14.0134 0 13.9485V13.9472C0 13.9427 0 13.9376 0 13.9325C0 13.7339 0.150732 13.5694 0.348151 13.5392H0.350819C2.1536 13.1061 3.60089 11.9154 4.32921 10.3469L4.34388 10.3109L4.35722 10.2877C4.44593 10.1624 4.49862 10.0076 4.49862 9.84114C4.49862 9.75118 4.48328 9.66507 4.45526 9.58411L4.45726 9.58989C4.29453 9.24161 3.72028 9.06169 3.34678 8.94024C3.23474 8.91261 3.13869 8.87984 3.04665 8.84L3.05866 8.8445C2.13626 8.49493 2.01087 8.09782 2.06089 7.82215C2.19895 7.44752 2.56311 7.18471 2.9913 7.18471C3.00664 7.18471 3.02131 7.18535 3.03665 7.18599H3.03465C3.03532 7.18599 3.03532 7.18599 3.03665 7.18599C3.1507 7.18599 3.26008 7.20784 3.35946 7.24768L3.35412 7.24575C3.62157 7.38134 3.93504 7.46809 4.26852 7.48608H4.27452C4.28252 7.48608 4.29119 7.48672 4.30053 7.48672C4.43259 7.48672 4.55731 7.45523 4.66669 7.39997L4.66269 7.4019L4.62467 6.94502C4.56264 6.54148 4.52663 6.07497 4.52663 5.60074C4.52663 4.69727 4.65602 3.82208 4.89679 2.99315L4.88012 3.06126C5.70514 1.25239 7.5486 0.0115665 9.69287 0.0115665C9.72221 0.0115665 9.75156 0.0115664 9.78024 0.012209H9.77557L10.1251 0H10.1751L10.1711 0.00192776Z"
                            fill="#124651"
                          />
                        </svg>
                      </a>
                    </li>
                  </ul>
                </div>
              </Box>
            </Grid>

            <Grid
              item
              xs={12}
              md={4}
              sx={{
                display: "flex",
                alignItems: { xs: "flex-start", md: "center" },

                gap: "3.2rem",

                flexDirection: "column",
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  alignItems: "flex-start",
                  gap: { xs: "2rem", md: "3.2rem" },
                  flexDirection: "column",
                }}
              >
                <Typography
                  variant="body2"
                  sx={{
                    // fontFamily: "var(--font-ibm-plex-sans-arabic)",
                    fontSize: { xs: "2rem", md: "1.6rem" },
                    fontWeight: 700,
                    lineHeight: "2.2rem",
                    color: "#e1e42a",
                  }}
                >
                  روابط تهمك
                </Typography>

                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "2.4rem",
                  }}
                >
                  <Typography
                    variant="body2"
                    sx={{
                      fontFamily: "Kumbh Sans, sans-serif",
                      fontSize: "1.6rem",
                      fontWeight: 400,
                      cursor: "pointer",

                      lineHeight: "1.6rem",
                      transition: "color 0.3s ease",
                      "&:hover": {
                        color: " #e0e324",
                      },
                    }}
                    onClick={() => handleNavigation("/about-us")}
                  >
                    من نحن
                  </Typography>

                  <Typography
                    variant="body2"
                    sx={{
                      fontFamily: "Kumbh Sans, sans-serif",
                      fontSize: "1.6rem",
                      fontWeight: 400,
                      cursor: "pointer",

                      lineHeight: "1.6rem",
                      transition: "color 0.3s ease",
                      "&:hover": {
                        color: " #e0e324",
                      },
                    }}
                    onClick={() => handleNavigation("/mobile-apps")}
                  >
                    تطبيقات الموبايل
                  </Typography>

                  <Typography
                    variant="body2"
                    sx={{
                      fontFamily: "Kumbh Sans, sans-serif",
                      fontSize: "1.6rem",
                      fontWeight: 400,
                      cursor: "pointer",

                      lineHeight: "1.6rem",
                      transition: "color 0.3s ease",
                      "&:hover": {
                        color: " #e0e324",
                      },
                    }}
                    onClick={() => handleNavigation("/mobile-apps")}
                  >
                    متاجر إلكترونية
                  </Typography>

                  <Typography
                    variant="body2"
                    sx={{
                      fontFamily: "Kumbh Sans, sans-serif",
                      fontSize: "1.6rem",
                      fontWeight: 400,
                      lineHeight: "1.6rem",
                      cursor: "pointer",
                      transition: "color 0.3s ease",
                      "&:hover": {
                        color: " #e0e324",
                      },
                    }}
                    onClick={() => {
                      handleNavigation("/design-and-marketing")
                    }}
                  >
                    التصميم والموشن
                  </Typography>
                  <Typography
                    variant="body2"
                    sx={{
                      fontFamily: "Kumbh Sans, sans-serif",
                      fontSize: "1.6rem",
                      fontWeight: 400,
                      lineHeight: "1.6rem",
                      cursor: "pointer",
                      transition: "color 0.3s ease",
                      "&:hover": {
                        color: " #e0e324",
                      },
                    }}
                    onClick={() => {
                      handleNavigation("/marketing-and-campaigns")
                    }}
                  >
                    التسويق والحملات
                  </Typography>
                </Box>
              </Box>
            </Grid>

            {/* Column 3 */}
            <Grid
              item
              xs={12}
              md={4}
              sx={{
                display: "flex",
                alignItems: { xs: "flex-start", md: "center" },
                gap: "3.2rem",
                flexDirection: "column",
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  alignItems: "flex-start",
                  gap: { xs: "2rem", md: "3.2rem" },
                  flexDirection: "column",
                }}
              >
                <Typography
                  variant="body2"
                  sx={{
                    // fontFamily: "var(--font-ibm-plex-sans-arabic)",
                    fontSize: { xs: "2rem", md: "1.6rem" },
                    fontWeight: 700,
                    lineHeight: "2.2rem",
                    color: "#e1e42a",
                  }}
                >
                  العناوين
                </Typography>

                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    gap: "2.4rem",
                  }}
                >
                  <Typography
                    variant="body2"
                    sx={{
                      fontFamily: "Kumbh Sans, sans-serif",
                      fontSize: "1.6rem",
                      fontWeight: 400,
                      lineHeight: "1.6rem",
                      display: "flex",
                      alignItems: "center",
                      gap: "1rem",
                    }}
                  >
                    <Image src={email} alt="email" width={34} height={34} />

                    <a href="mailto:contact@inbrief.click" style={{ color: "white" }}>
                      contact@inbrief.click
                    </a>
                  </Typography>
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      gap: ".8rem",
                    }}
                  >
                    <Typography
                      variant="body2"
                      sx={{
                        fontFamily: "Kumbh Sans, sans-serif",
                        fontSize: "1.6rem",
                        fontWeight: 400,
                        lineHeight: "1.6rem",
                        display: "flex",
                        alignItems: "center",
                        gap: "1rem",
                      }}
                    >
                      <Image src={location} alt="location" width={34} height={34} />

                      <span style={{ lineHeight: "2rem" }}>
                        <strong>الدمام</strong> : طريق الملك فهد مع طريق عثمان ابن عفان مقابل عمارة المعجل
                      </span>
                    </Typography>
                    <Typography
                      variant="body2"
                      sx={{
                        fontFamily: "Kumbh Sans, sans-serif",
                        fontSize: "1.6rem",
                        fontWeight: 400,
                        lineHeight: "1.6rem",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        gap: "1rem",
                      }}
                    >
                      <Image src={phone} alt="phone" width={34} height={34} />

                      <strong>
                        <a href="http://wa.me/966552647805" target="_blank" style={{ color: "white" }}>
                          966552647805+
                        </a>
                      </strong>
                    </Typography>
                  </Box>
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      gap: ".8rem",
                    }}
                  >
                    <Typography
                      variant="body2"
                      sx={{
                        fontFamily: "Kumbh Sans, sans-serif",
                        fontSize: "1.6rem",
                        fontWeight: 400,
                        lineHeight: "1.6rem",
                        display: "flex",
                        alignItems: "center",
                        gap: "1rem",
                      }}
                    >
                      <Image src={location} alt="location" width={34} height={34} />

                      <span style={{ lineHeight: "2.5rem" }}>
                        <strong>الكويت</strong>: الفروانية - خيطان - الهيئة العامه للاستثمار -الدور الأول - 13
                      </span>
                    </Typography>
                    <Typography
                      variant="body2"
                      sx={{
                        fontFamily: "Kumbh Sans, sans-serif",
                        fontSize: "1.6rem",
                        fontWeight: 400,
                        lineHeight: "1.6rem",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        gap: "1rem",
                      }}
                    >
                      <Image src={phone} alt="phone" width={34} height={34} />

                      <strong>
                        <a href="http://wa.me/96550337772" target="_blank" style={{ color: "white" }}>
                          96550337772+
                        </a>
                      </strong>
                    </Typography>
                  </Box>
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      gap: ".8rem",
                    }}
                  >
                    <Typography
                      variant="body2"
                      sx={{
                        fontFamily: "Kumbh Sans, sans-serif",
                        fontSize: "1.6rem",
                        fontWeight: 400,
                        lineHeight: "1.6rem",
                        display: "flex",
                        alignItems: "center",
                        gap: "1rem",
                      }}
                    >
                      <Image src={location} alt="location" width={34} height={34} />

                      <span>
                        <strong>مسقط</strong>: العذيبة - ١٨نوفمبر -مقابل بنك مسقط
                      </span>
                    </Typography>
                    <Typography
                      variant="body2"
                      sx={{
                        fontFamily: "Kumbh Sans, sans-serif",
                        fontSize: "1.6rem",
                        fontWeight: 400,
                        lineHeight: "1.6rem",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        gap: "1rem",
                      }}
                    >
                      <Image src={phone} alt="phone" width={34} height={34} />

                      <strong>
                        <a href="http://wa.me/96877276659" target="_blank" style={{ color: "white" }}>
                          96877276659+
                        </a>
                      </strong>
                    </Typography>
                  </Box>
                </Box>
              </Box>
            </Grid>
          </Grid>
          <Box
            sx={{
              width: "100%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              gap: "1.6rem",
            }}
          >
            <ScrollTop />
          </Box>
          <div
            style={{
              width: "100%",
              height: "1px",
              background: "#FFFFFF1F",
              marginBottom: "2rem",
            }}
          ></div>

          <Typography
            variant="body2"
            sx={{
              fontFamily: "Kumbh Sans, sans-serif",
              fontSize: "1.6rem",
              fontWeight: 400,
              lineHeight: "1.6rem",
              textAlign: "center",
            }}
          >
            ⁠جميع الحقوق محفوظة لشركة Inbrief للبرمجيات والتسويق 2025
          </Typography>
        </Box>
      </Container>
    </Box>
  )
}
